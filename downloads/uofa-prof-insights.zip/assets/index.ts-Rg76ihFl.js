import{a as e,d as t,f as n,l as r,m as i,o as a,p as o,r as s,s as c,t as l,u}from"./utils-DSUDHu2-.js";import{t as d}from"./messaging-DQBs0SHq.js";var f=`upi-badge`,p=`upi-badge-click`,ee=`
  :host {
    --upi-fg: #fff;
    --upi-bg: ${n};
    --upi-radius: 3px;

    display: inline-flex;
    align-items: center;
    vertical-align: middle;
    margin-left: 6px;
    /* Inherit UAccess's font so the badge reads as part of the page. */
    font-family: inherit;
    font-size: 0.85em;
    line-height: 1;
    cursor: pointer;
    user-select: none;
  }

  .badge {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    padding: 2px 6px;
    border-radius: var(--upi-radius);
    background: var(--upi-bg);
    color: var(--upi-fg);
    font-weight: 600;
    white-space: nowrap;
    transition: filter 120ms ease-in-out;
  }

  :host(:hover) .badge {
    filter: brightness(1.08);
  }

  :host(:focus-visible) {
    outline: 2px solid #0c234b; /* UofA blue */
    outline-offset: 2px;
    border-radius: var(--upi-radius);
  }

  .count {
    font-weight: 400;
    opacity: 0.85;
    font-size: 0.9em;
  }

  /* Rank pill, shown only when this professor is the pick of the page. */
  .rank {
    display: inline-flex;
    align-items: center;
    margin-left: 4px;
    padding: 1px 5px;
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.28);
    font-size: 0.85em;
    font-weight: 700;
    letter-spacing: 0.02em;
  }

  /* Loading skeleton */
  .badge.is-loading {
    background: #e3e3e3;
    color: transparent;
    min-width: 34px;
    min-height: 1.15em;
    animation: upi-pulse 1.2s ease-in-out infinite;
  }

  @keyframes upi-pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.55; }
  }

  @media (prefers-reduced-motion: reduce) {
    .badge.is-loading { animation: none; }
  }
`,te=class e{static styles=ee;el;#e;#t;#n=`loading`;#r=null;constructor(t=document){this.el=t.createElement(f),this.#e=this.el.attachShadow({mode:`open`});let n=t.createElement(`style`);n.textContent=e.styles,this.#t=t.createElement(`span`),this.#t.className=`badge`,this.#e.append(n,this.#t),this.el.setAttribute(`role`,`button`),this.el.setAttribute(`tabindex`,`0`),this.el.addEventListener(`click`,this.#i),this.el.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),this.#i())}),m.set(this.el,this),this.#a()}get dataset(){return this.el.dataset}remove(){this.el.remove()}get isConnected(){return this.el.isConnected}click(){this.el.click()}addEventListener(e,t){this.el.addEventListener(e,t)}get shadowRoot(){return this.#e}#i=()=>{this.el.dispatchEvent(new CustomEvent(p,{detail:this.#n,bubbles:!0,composed:!0}))};get data(){return this.#n}set data(e){this.#n=e,this.#a()}get rank(){return this.#r}set rank(e){this.#r=e,this.#a()}#a(){let e=this.el.ownerDocument,t=this.#n;if(this.#t.classList.toggle(`is-loading`,t===`loading`),t===`loading`){this.#t.textContent=`   `,this.#o(`Looking up Rate My Professors…`,n,`Loading professor rating`);return}if(t===`error`){this.#t.textContent=`?`,this.#o(`Could not reach Rate My Professors. Click to retry`,r,`Rating unavailable`);return}if(t===null){this.#t.textContent=`N/A`,this.#o(`No Rate My Professors match for this instructor`,n,`No rating found`);return}if(t.overallRating===null){this.#t.textContent=`N/A`,this.#o(`${t.name} is on Rate My Professors but has no ratings yet`,n,`${t.name}: no ratings yet`);return}let i=t.overallRating.toFixed(1),a=e.createElement(`span`);if(a.className=`count`,a.textContent=`(${t.numRatings})`,this.#t.replaceChildren(e.createTextNode(`★ ${i}`),a),this.#r!==null&&this.#r.rank===1&&this.#r.total>1){let t=e.createElement(`span`);t.className=`rank`,t.textContent=`BEST`,this.#t.appendChild(t)}let o=t.numRatings===1?`rating`:`ratings`,c=this.#r!==null&&this.#r.total>1?` · ranked ${this.#r.rank} of ${this.#r.total} rated instructors here`:``;this.#o(`Based on ${t.numRatings} ${o} on RMP${c}`,s(t.overallRating),`${t.name}: ${i} out of 5, based on ${t.numRatings} ${o}${c}`)}#o(e,t,n){this.el.title=e,this.el.style.setProperty(`--upi-bg`,t),this.el.setAttribute(`aria-label`,n)}get title(){return this.el.title}get style(){return this.el.style}getAttribute(e){return this.el.getAttribute(e)}},m=new WeakMap;function ne(e){return e?m.get(e)??null:null}function h(e){return[...e.querySelectorAll(f)].map(e=>m.get(e)).filter(e=>e!==void 0)}var re=`CLASS_SRCH_WRK2_STRM$scroll$`,ie=`CLASS_SRCH_WRK2_STRM_INSTRUCTOR$`,ae=`MTG_INSTR$`;function g(e){let t=Number.parseInt(e.getAttribute(`colspan`)??`1`,10);return Number.isFinite(t)&&t>0?t:1}function oe(e){let t=e.querySelector(`th[id^="${ie}"]`),n=t?.parentElement;if(!t||!n)return null;let r=0;for(let e of n.children){if(e===t)return r;r+=g(e)}return null}function se(e,t){let n=0;for(let r of e.children){let e=g(r);if(t>=n&&t<n+e)return r.tagName===`TD`?r:null;n+=e}return null}function _(e){let t=[],n=``;for(let r of e.childNodes)r.nodeType===1&&r.tagName===`BR`?(t.push(n),n=``):n+=r.textContent??``;return t.push(n),t.map(e=>e.trim().replace(/\s+/g,` `)).filter(Boolean)}function v(e){return!i.has(e.trim().toLowerCase())}function ce(t,n){let r=t.querySelector(`td`),i=e(r?.textContent??null);if(i)return i;let a=n.previousElementSibling?.textContent??``;return e(a.split(/[-\u2013\u2014]/)[0]??null)??void 0}function le(e){let t=[],n=oe(e);for(let r of e.rows){if(!r.querySelector(`td`))continue;let i=r.querySelector(`td[id^="${ae}"]`)??(n===null?null:se(r,n));if(!i)continue;let o=ce(r,e);for(let e of _(i))v(e)&&t.push({element:i,name:a(e),rawName:e,...o?{courseCode:o}:{}})}return t}function y(e){let t=e.querySelectorAll(`table[id^="${re}"]`),n=[];for(let e of t)n.push(...le(e));return n.length>0&&console.info(`[UPI] classic detector found ${n.length} instructor(s) across ${t.length} table(s):`,n.map(e=>e.name)),n}var ue=/\b[A-Z]{2,5}\s?\d{3}[A-Z]?\b/,de=/^\p{Lu}[\p{L}'’-]+(?:\s+(?:van|von|de|del|della|di|da|du|la|le|of|bin|al)\s+|\s+)(?:\p{Lu}[\p{L}'’-]+)(?:\s+\p{Lu}[\p{L}'’-]+){0,2}$/u,fe=new Set(`academic add advanced advising aerospace aid algebra algorithms american analysis ancient
   application applied architecture array art artificial basic biology biomedical bldg building
   business calculus calendar campus capacity career catalog center chemical chemistry civil
   class classes closed cloud communication comparative compiler compilers component composition
   computer computing concepts contemporary course courses credit credits data database databases
   day days deadlines degree description design details differential digital discrete discussion
   distributed drop dropped earth economics edit education electrical elementary end engineering
   enroll enrolled enrollment environment exam experimental fall field film filter final financial
   freshman fundamentals general global grade grades grading graduate graphics hardware help
   history home honors hours human independent industrial information inorganic instruction
   instructor intelligence interaction interface international internship introduction junior lab
   laboratory law learning lecture library life linear list literature location logic machine
   main management materials mathematics mechanical media medicine medieval meeting mobile modern
   more music my natural nbr network networks none number numerical nursing online open operating
   options organic parallel personal pharmacy philosophy physical physics planning points
   practicum prerequisites principles print programming psychology qualitative quantitative quiz
   record records regular requirements research results room schedule science search seat seats
   second section security selected seminar senior session showing social sociology software
   sophomore space special spring staff start statistics status structure structures student
   studies subject summer sustainability swap syllabus systems term textbook theater theatre
   theoretical theory thesis third time times title to topics total transcript undergraduate
   units update view vision waitlist waitlisted web weekly winter withdraw world writing year
   in person mode instruction meeting information session component career campus hybrid remote
   asynchronous synchronous lab lecture discussion open closed full reserved consent permission
   required optional cart shopping select details expand collapse modify results found sections`.split(/\s+/).filter(Boolean));function pe(e){let t=e.toLowerCase().replace(/[^a-z\s]/g,` `).split(/\s+/).filter(Boolean);return t.length===0||t.every(e=>fe.has(e))}var me=`nav, header, footer, [role="navigation"], [role="banner"], upi-card, upi-filter`,b=15;function he(e){let t=e.trim();return t.length<5||t.length>60||/\d/.test(t)||i.has(t.toLowerCase())||pe(t)?!1:de.test(t)}function ge(e){let t=e.parentElement;for(let e=0;t&&e<b;e++){if(t.tagName===`BODY`)return!1;if(ue.test(t.textContent??``))return!0;t=t.parentElement}return!1}function x(e){let t=[],n=e.createTreeWalker(e.body??e,NodeFilter.SHOW_TEXT);for(let e=n.nextNode();e;e=n.nextNode()){let n=(e.textContent??``).trim().replace(/\s+/g,` `);if(!n||n.length<5||n.length>120)continue;let r=e.parentElement;r&&(r.closest(me)||r.tagName!==`SCRIPT`&&r.tagName!==`STYLE`&&t.push({element:r,text:n}))}return t}function S(e){let t=[],n=new Set;for(let{element:r,text:i}of x(e)){if(n.has(r))continue;let e=c(i,`natural-list`);if(e.length===0||!e.every(he)||!ge(r))continue;n.add(r);let a=_e(r);for(let n of e)t.push({element:r,name:n,rawName:i,speculative:!0,...a?{courseCode:a}:{}})}return t.length>0&&console.info(`[UPI] generic detector found ${t.length} instructor(s):`,t.map(e=>e.name)),t}function _e(e){let t=e.parentElement;for(let e=0;t&&e<b&&t.tagName!==`BODY`;e++){let e=ue.exec(t.textContent??``);if(e)return e[0].replace(/\s+/g,``).toUpperCase();t=t.parentElement}}var ve=`div.resultPanel`,ye=`div.instructor`;function C(t){let n=t.querySelectorAll(ve),r=[];for(let t of n){let n=e(t.querySelector(`.courseCode`)?.textContent??null)??void 0;for(let e of t.querySelectorAll(ye))for(let t of _(e))v(t)&&r.push({element:e,name:a(t),rawName:t,...n?{courseCode:n}:{}})}return r.length>0&&console.info(`[UPI] new detector found ${r.length} instructor(s) across ${n.length} panel(s):`,r.map(e=>e.name)),r}function be(e){let t=[...y(e),...C(e)];return t.length>0?t:S(e)}var xe=1;function Se(e){let t=[...e.addedNodes,...e.removedNodes];return t.length!==0&&t.every(e=>e.nodeType===xe&&e.tagName.toLowerCase()===f)}function Ce(e,t){let n=null,r=!1,i=()=>{if(!r)try{t(be(e))}catch(e){console.error(`[UPI] detection pass failed:`,e)}},a=()=>{n!==null&&clearTimeout(n),n=setTimeout(i,250)};i();let o=new MutationObserver(e=>{e.every(Se)||a()}),s=e.body??e.documentElement;return s&&o.observe(s,{childList:!0,subtree:!0}),()=>{r=!0,n!==null&&clearTimeout(n),o.disconnect()}}var we=`upi-card`,w=`upi-card-refresh`,Te=`
  :host {
    position: absolute;
    z-index: 2147483647;
    display: block;
    width: 268px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    font-size: 13px;
    line-height: 1.4;
    color: #1a1a1a;
  }

  .card {
    background: #fff;
    border: 1px solid #d6d6d6;
    border-radius: 6px;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
    padding: 12px 14px;
  }

  header { margin-bottom: 10px; padding-right: 20px; }

  .name { font-weight: 600; font-size: 14px; }
  .dept { color: #666; font-size: 12px; margin-top: 1px; }

  .close {
    position: absolute;
    top: 8px;
    right: 8px;
    width: 22px;
    height: 22px;
    border: 0;
    border-radius: 3px;
    background: transparent;
    color: #666;
    font-size: 16px;
    line-height: 1;
    cursor: pointer;
  }
  .close:hover { background: #eee; color: #111; }

  .stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 6px;
    margin-bottom: 10px;
  }

  .stat {
    background: #f6f6f6;
    border-radius: 4px;
    padding: 6px 4px;
    text-align: center;
  }
  .stat .value { font-weight: 700; font-size: 15px; }
  .stat .label { color: #666; font-size: 10px; text-transform: uppercase; letter-spacing: 0.03em; }
  .stat.primary .value { color: var(--upi-rating-color, ${n}); }

  .tags { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 10px; }
  .tag {
    background: #eef2f8;
    color: #26436e;
    border-radius: 10px;
    padding: 2px 8px;
    font-size: 11px;
    white-space: nowrap;
  }

  .empty { color: #666; font-size: 12px; margin-bottom: 10px; }

  .section {
    margin-bottom: 10px;
    padding-top: 8px;
    border-top: 1px solid #eee;
  }
  .section h3 {
    margin: 0 0 5px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: #666;
  }

  .course {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 8px;
    padding: 2px 0;
  }
  .course .code { font-weight: 600; }
  .course .n { color: #888; font-size: 11px; }
  .course .score { font-weight: 700; color: var(--course-color, #1a1a1a); }
  .course.is-current .code::after {
    content: ' · this course';
    font-weight: 400;
    color: #0c234b;
    font-size: 11px;
  }

  .facts { margin: 0; padding-left: 15px; }
  .facts li { padding: 1px 0; }

  .phrases { display: flex; flex-wrap: wrap; gap: 4px; }
  .phrase {
    display: inline-flex;
    align-items: baseline;
    gap: 4px;
    background: #f2f4f7;
    border-radius: 3px;
    padding: 2px 6px;
    font-size: 11px;
  }
  .phrase-n { color: #8a8a8a; font-size: 10px; }

  .alt {
    display: block;
    color: #555;
    font-size: 11px;
    text-decoration: none;
    padding: 1px 0;
  }
  .alt:hover { text-decoration: underline; }
  .alt .why { color: #888; }

  a.rmp {
    display: inline-block;
    color: #0c234b;
    font-weight: 600;
    font-size: 12px;
    text-decoration: none;
  }
  a.rmp:hover { text-decoration: underline; }

  footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    color: #999;
    font-size: 10px;
    margin-top: 8px;
  }

  .refresh {
    border: 0;
    background: transparent;
    color: #0c234b;
    font: inherit;
    font-size: 10px;
    font-weight: 600;
    cursor: pointer;
    padding: 2px 4px;
    border-radius: 3px;
  }
  .refresh:hover:not(:disabled) { background: #eef2f8; }
  .refresh:disabled { color: #999; cursor: default; }
`;function T(e){return e===null?`N/A`:e.toFixed(1)}function Ee(e){return e===null?`N/A`:`${Math.round(e)}%`}var De=class t{static styles=Te;el;#e;#t;#n;#r=null;#i=!1;#a=null;constructor(e=document){this.#e=e,this.el=e.createElement(we),this.#t=this.el.attachShadow({mode:`open`});let n=e.createElement(`style`);n.textContent=t.styles,this.#n=e.createElement(`div`),this.#n.className=`card`,this.#t.append(n,this.#n),this.el.setAttribute(`role`,`dialog`)}get dataset(){return this.el.dataset}get style(){return this.el.style}get isConnected(){return this.el.isConnected}get shadowRoot(){return this.#t}contains(e){return this.el.contains(e)}remove(){this.el.remove()}addEventListener(e,t){this.el.addEventListener(e,t)}get data(){return this.#r}set data(e){this.#r=e,this.#i=!1,this.#o()}get courseCode(){return this.#a}set courseCode(e){this.#a=e,this.#o()}get busy(){return this.#i}set busy(e){this.#i=e,this.#o()}#o(){let e=this.#e,t=this.#r;if(this.#n.replaceChildren(),!t)return;this.el.setAttribute(`aria-label`,`Rate My Professors details for ${t.name}`),this.el.style.setProperty(`--upi-rating-color`,s(t.overallRating));let n=e.createElement(`button`);n.className=`close`,n.type=`button`,n.textContent=`×`,n.setAttribute(`aria-label`,`Close`),n.addEventListener(`click`,e=>{e.stopPropagation(),this.remove()});let r=e.createElement(`header`),i=e.createElement(`div`);i.className=`name`,i.textContent=t.name;let a=e.createElement(`div`);a.className=`dept`,a.textContent=`${t.department} · ${t.university}`,r.append(i,a);let o=e.createElement(`div`);if(o.className=`stats`,o.append(this.#d(T(t.overallRating),`Rating`,!0),this.#d(T(t.difficulty),`Difficulty`),this.#d(Ee(t.wouldTakeAgain),`Would retake`)),this.#n.append(n,r,o),t.topTags.length>0){let n=e.createElement(`div`);n.className=`tags`;for(let r of t.topTags){let t=e.createElement(`span`);t.className=`tag`,t.textContent=r,n.appendChild(t)}this.#n.appendChild(n)}else{let n=e.createElement(`div`);n.className=`empty`,n.textContent=t.numRatings===0?`No ratings on Rate My Professors yet.`:`No tags for this professor.`,this.#n.appendChild(n)}this.#s(t),this.#c(t),this.#l(t),this.#u(t);let c=e.createElement(`a`);c.className=`rmp`,c.href=t.rmpUrl,c.target=`_blank`,c.rel=`noopener noreferrer`;let u=t.numRatings===1?`rating`:`ratings`;c.textContent=`View ${t.numRatings} ${u} on RMP →`;let d=e.createElement(`span`);d.textContent=this.#i?`Refreshing…`:`Cached ${l(t.cachedAt)}`;let f=e.createElement(`button`);f.className=`refresh`,f.type=`button`,f.textContent=`Refresh`,f.disabled=this.#i,f.addEventListener(`click`,e=>{e.stopPropagation(),this.busy=!0,this.el.dispatchEvent(new CustomEvent(w,{detail:t,bubbles:!0,composed:!0}))});let p=e.createElement(`footer`);p.append(d,f),this.#n.append(c,p)}#s(t){let n=t.courseRatings??[];if(n.length===0)return;let r=this.#e,i=this.#a?e(this.#a):null,a=[...n].sort((e,t)=>e.course===i?-1:t.course===i?1:t.numRatings-e.numRatings),o=r.createElement(`div`);o.className=`section`;let c=r.createElement(`h3`);c.textContent=`Recent ratings by course`,o.appendChild(c);for(let e of a.slice(0,4)){let t=r.createElement(`div`);t.className=e.course===i?`course is-current`:`course`;let n=r.createElement(`span`);n.className=`code`,n.textContent=e.course;let a=r.createElement(`span`),c=r.createElement(`span`);c.className=`score`,c.textContent=e.rating===null?`N/A`:e.rating.toFixed(1),c.style.setProperty(`--course-color`,s(e.rating));let l=r.createElement(`span`);l.className=`n`,l.textContent=` (${e.numRatings})`,a.append(c,l),t.append(n,a),o.appendChild(t)}this.#n.appendChild(o)}#c(e){let t=e.reviewInsights;if(!t)return;let n=[];if(t.attendanceMandatoryPct!==null&&n.push(t.attendanceMandatoryPct>=50?`Attendance mandatory (${t.attendanceMandatoryPct}% say so)`:`Attendance flexible (${100-t.attendanceMandatoryPct}% say so)`),t.textbookUsedPct!==null&&n.push(t.textbookUsedPct>=50?`Textbook used (${t.textbookUsedPct}%)`:`Textbook rarely used (${100-t.textbookUsedPct}%)`),t.onlinePct!==null&&t.onlinePct>=25&&n.push(`${t.onlinePct}% taken online`),t.topGrade&&t.gradesReported>=3&&n.push(`Most reported grade: ${t.topGrade}`),n.length===0)return;let r=this.#e,i=r.createElement(`div`);i.className=`section`;let a=r.createElement(`h3`);a.textContent=`What to expect`,i.appendChild(a);let o=r.createElement(`ul`);o.className=`facts`;for(let e of n){let t=r.createElement(`li`);t.textContent=e,o.appendChild(t)}i.appendChild(o),this.#n.appendChild(i)}#l(e){let t=e.reviewInsights?.phrases??[];if(t.length===0)return;let n=this.#e,r=n.createElement(`div`);r.className=`section`;let i=n.createElement(`h3`);i.textContent=`Repeated in ${e.reviewInsights?.reviewsRead??0} recent reviews`,r.appendChild(i);let a=n.createElement(`div`);a.className=`phrases`;for(let{phrase:e,mentions:r}of t){let t=n.createElement(`span`);t.className=`phrase`,t.textContent=e;let i=n.createElement(`span`);i.className=`phrase-n`,i.textContent=`×${r}`,t.appendChild(i),a.appendChild(t)}r.appendChild(a),this.#n.appendChild(r)}#u(e){let t=e.alternateProfiles??[];if(t.length===0)return;let n=this.#e,r=n.createElement(`div`);r.className=`section`;let i=n.createElement(`h3`);i.textContent=e.matchConfidence===`nickname`?`Also listed on RMP as`:`Duplicate profiles`,r.appendChild(i);for(let e of t.slice(0,3)){let t=n.createElement(`a`);t.className=`alt`,t.href=e.rmpUrl,t.target=`_blank`,t.rel=`noopener noreferrer`;let i=e.overallRating===null?`unrated`:e.overallRating.toFixed(1),a=e.numRatings===1?`rating`:`ratings`;t.append(n.createTextNode(`${e.name}: ${i} `),Object.assign(n.createElement(`span`),{className:`why`,textContent:`(${e.numRatings} ${a})`})),r.appendChild(t)}this.#n.appendChild(r)}#d(e,t,n=!1){let r=this.#e,i=r.createElement(`div`);i.className=n?`stat primary`:`stat`;let a=r.createElement(`div`);a.className=`value`,a.textContent=e;let o=r.createElement(`div`);return o.className=`label`,o.textContent=t,i.append(a,o),i}},E=null,D=null,O=null,Oe=268,ke=6,k=8;function Ae(e,t,n,r){let i=e.left+n,a=n+t-Oe-k,o=n+k;return{left:Math.round(Math.max(o,Math.min(i,a))),top:Math.round(e.bottom+r+ke)}}function A(){O?.(),O=null,E?.remove(),E=null,D=null}function je(){D&&!D.isConnected&&A()}function j(e,t){!E||E.data?.name!==e||(t?E.data=t:A())}function Me(e,t,n=null){let r=e.ownerDocument,i=r.defaultView;if(!i)return null;if(E&&E.dataset.upiAnchorId===N(e))return A(),null;A();let a=new De(r);a.dataset.upiAnchorId=N(e),a.courseCode=n,a.data=t;let{left:o,top:s}=Ae(e.getBoundingClientRect(),i.innerWidth,i.scrollX,i.scrollY);a.style.left=`${o}px`,a.style.top=`${s}px`,r.body.appendChild(a.el),E=a,D=e;let c=t=>{let n=t.target,r=t.composedPath?.()??[];r.includes(a.el)||r.includes(e)||n&&(a.contains(n)||e.contains(n))||A()},l=e=>{e.key===`Escape`&&A()};return r.addEventListener(`pointerdown`,c,!0),r.addEventListener(`keydown`,l,!0),O=()=>{r.removeEventListener(`pointerdown`,c,!0),r.removeEventListener(`keydown`,l,!0)},a}var M=0;function N(e){return e.dataset.upiAnchorId||(M+=1,e.dataset.upiAnchorId=String(M)),e.dataset.upiAnchorId}var P=new Map;function F(e){return P.get(e)??[]}function Ne(e){Pe();let t=[];for(let n of e){let{element:e,name:r}=n;if(F(e).some(e=>e.dataset.upiName===r))continue;let i=new te(e.ownerDocument);i.dataset.upiName=r,i.data=`loading`,i.addEventListener(p,e=>{let t=e.detail;console.info(`[UPI] badge clicked for ${r}:`,t),t&&t!==`loading`&&t!==`error`&&Me(i.el,t,n.courseCode??null)}),e.appendChild(i.el),P.set(e,[...F(e),i]),t.push({badge:i,professor:n})}return t.length>0&&console.info(`[UPI] Injected ${t.length} badges`),t}function Pe(){let e=0;for(let[t,n]of P)if(!t.isConnected){for(let e of n)e.remove();P.delete(t),e+=n.length}return e>0&&(je(),console.info(`[UPI] Removed ${e} badges`)),e}var Fe=`upi-filter`,I=`upi-filter-change`,L={floor:null,includeUnrated:!0},Ie=[{label:`All`,value:null,color:n},{label:`2.5+`,value:2.5,color:t},{label:`3.5+`,value:3.5,color:u},{label:`4+`,value:4,color:u}],Le=`
  :host {
    display: block;
    margin: 8px 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    font-size: 12px;
    color: #1a1a1a;
  }

  .bar {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 8px;
    padding: 8px 10px;
    border: 1px solid #dfe3e8;
    border-left: 3px solid #ab0532;
    border-radius: 4px;
    background: #f8f9fb;
  }

  .label { font-weight: 700; }

  .group { display: inline-flex; border: 1px solid #cfd6de; border-radius: 4px; overflow: hidden; }

  .group button {
    border: 0;
    border-right: 1px solid #cfd6de;
    background: #fff;
    font: inherit;
    padding: 3px 9px;
    cursor: pointer;
    color: #333;
  }
  .group button:last-child { border-right: 0; }
  .group button:hover { background: #eef2f7; }
  .group button[aria-pressed='true'] {
    background: var(--accent, #0c234b);
    color: #fff;
    font-weight: 700;
  }

  label.toggle { display: inline-flex; align-items: center; gap: 5px; cursor: pointer; }

  .count { color: #5a6472; margin-left: auto; }
  .count strong { color: #1a1a1a; }
`,Re=class e{static styles=Le;el;#e;#t;#n;#r={...L};#i=0;#a=0;#o=0;constructor(t=document){this.#e=t,this.el=t.createElement(Fe),this.#t=this.el.attachShadow({mode:`open`});let n=t.createElement(`style`);n.textContent=e.styles,this.#n=t.createElement(`div`),this.#n.className=`bar`,this.#t.append(n,this.#n),this.el.setAttribute(`role`,`group`),this.el.setAttribute(`aria-label`,`Filter sections by instructor rating`),this.#c()}get isConnected(){return this.el.isConnected}get shadowRoot(){return this.#t}remove(){this.el.remove()}addEventListener(e,t){this.el.addEventListener(e,t)}get state(){return this.#r}set state(e){this.#r=e,this.#c()}setCounts(e,t,n){this.#i=e,this.#a=t,this.#o=n,this.#c()}#s(){this.el.dispatchEvent(new CustomEvent(I,{detail:this.#r,bubbles:!0,composed:!0}))}#c(){let e=this.#e;this.#n.replaceChildren();let t=e.createElement(`span`);t.className=`label`,t.textContent=`Instructor rating`;let n=e.createElement(`div`);n.className=`group`;for(let t of Ie){let r=e.createElement(`button`);r.type=`button`,r.textContent=t.label;let i=this.#r.floor===t.value;r.setAttribute(`aria-pressed`,String(i)),i&&t.value!==null&&r.style.setProperty(`--accent`,t.color),r.addEventListener(`click`,()=>{this.#r={...this.#r,floor:t.value},this.#c(),this.#s()}),n.appendChild(r)}let r=e.createElement(`label`);r.className=`toggle`;let i=e.createElement(`input`);i.type=`checkbox`,i.checked=this.#r.includeUnrated,i.addEventListener(`change`,()=>{this.#r={...this.#r,includeUnrated:i.checked},this.#c(),this.#s()}),r.append(i,e.createTextNode(`Keep unrated`));let a=e.createElement(`span`);if(a.className=`count`,a.setAttribute(`role`,`status`),this.#o>0)a.textContent=`checking ${this.#o} more…`;else{let t=e.createElement(`strong`);t.textContent=`${this.#i}`,a.append(t,e.createTextNode(` of ${this.#a} sections shown`))}this.#n.append(t,n,r,a)}},R=null,z={...L},B=null,V=`data-upi-hidden`;function H(e){return e.closest(`tr`)??e.closest(`.classSection`)}function U(e,t){let n=e?.overallRating??null;return n===null?t.includeUnrated:t.floor===null||n>=t.floor}function W(e){e.hasAttribute(V)&&(e.style.display=e.getAttribute(V)??``,e.removeAttribute(V))}function ze(e){e.hasAttribute(V)||(e.setAttribute(V,e.style.display),e.style.display=`none`)}function Be(e){let t=e.parentElement;if(!t)return[e];let n=[...t.children];return e.tagName===`TR`?n.filter(e=>e.tagName===`TR`&&e.querySelector(`td`)!==null):n.filter(e=>e.classList.contains(`classSection`))}function Ve(e){let{professors:t,results:n}=e,r=new Map;for(let e of t){let t=H(e.element);t&&r.set(t,[...r.get(t)??[],e])}for(let e of[...r.keys()])for(let t of Be(e))r.has(t)||r.set(t,[]);let i=0;for(let[e,t]of r)(t.length===0?U(null,z):t.some(e=>U(n.get(e.name),z)))?(W(e),i+=1):ze(e);return{visible:i,total:r.size}}function He(e=document){for(let t of e.querySelectorAll(`[${V}]`))W(t)}function Ue(e,t){let n=new Set(t.professors.map(e=>H(e.element)).filter(Boolean));if(!t.enabled||n.size<2)return We(),He(e),null;if(B=t,!R||!R.isConnected){R=new Re(e),R.state=z,R.addEventListener(I,e=>{z=e.detail,B&&(G(B),B.onChange())});let t=[...n][0],r=t.closest(`table`)??t.closest(`.resultPanel`)??t;r.parentElement?.insertBefore(R.el,r)}return G(t),R}function G(e){let{visible:t,total:n}=Ve(e),r=e.professors.filter(t=>!e.results.has(t.name)).length;R?.setCounts(t,n,r)}function We(){R?.remove(),R=null}function K(e,t=4){let n=[];for(let r=e,i=0;r&&i<t&&r.tagName!==`BODY`;r=r.parentElement,i++){let e=r.id?`#${r.id}`:``,t=typeof r.className==`string`&&r.className.trim()?`.${r.className.trim().split(/\s+/).slice(0,3).join(`.`)}`:``;n.push(`${r.tagName.toLowerCase()}${e}${t}`)}return n.join(` < `)}function Ge(e,t){let n=[];for(let{element:r,text:i}of x(e)){if(n.length>=t)break;/^[A-Z][\w'’-]*(?:[\s,]+[A-Z][\w'’-]*){1,4}$/.test(i)&&n.push({text:i.slice(0,80),path:K(r)})}return n}function Ke(e){let t=y(e),n=C(e),r=t.length+n.length===0?S(e):[],i=[...t,...n,...r];return{url:e.location?.href??`unknown`,title:e.title,inFrame:e.defaultView!==e.defaultView?.top,classicCount:t.length,newCount:n.length,genericCount:r.length,badgesInPage:e.querySelectorAll(f).length,textRuns:x(e).length,names:i.slice(0,12).map(e=>e.name),samples:i.slice(0,6).map(e=>({text:e.rawName,path:K(e.element)})),nearMisses:i.length===0?Ge(e,12):[]}}console.log(`[UPI] Content script loaded on UAccess`);var q=`__upiTeardown`;function qe(){let e=window;try{e[q]?.()}catch(e){console.error(`[UPI] teardown of previous instance failed:`,e)}delete e[q]}var J={...o},Y=new Map,X=[];function Je(){let e=[...new Set(X.map(e=>e.name))].map(e=>({name:e,rating:Y.get(e)?.overallRating??null})).filter(e=>e.rating!==null).sort((e,t)=>t.rating-e.rating),t=e.length,n=new Map(e.map((e,t)=>[e.name,t+1]));for(let e of h(document)){let r=e.dataset.upiName,i=r?n.get(r):void 0;e.rank=i===void 0?null:{rank:i,total:t}}}function Z(){try{Ue(document,{enabled:J.showFilterBar,professors:X,results:Y,onChange:Z})}catch(e){console.error(`[UPI] filter update failed:`,e)}}async function Q(e,t,n=!1,r=!1){e.data=`loading`;try{let i=await d({type:n?`REFRESH_PROFESSOR`:`LOOKUP_PROFESSOR`,name:t},`PROFESSOR_RESULT`);if(r&&i.data===null){e.remove(),Y.set(t,null),Je();return}e.data=i.data,Y.set(t,i.data),j(t,i.data)}catch(n){e.data=`error`,Y.set(t,null),j(t,null),console.error(`[UPI] lookup failed for "${t}":`,n)}Je(),Z()}function Ye(e){for(let t of h(document))if(t.dataset.upiName===e)return t;return null}function Xe(e){let t=e.detail;if(t&&t!==`loading`&&t!==`error`){d({type:`RECORD_VIEW`,data:t},`USAGE`).catch(()=>{});return}if(t!==`error`)return;let n=ne(e.target),r=n?.dataset.upiName;n&&r&&Q(n,r,!0)}function Ze(e){let t=e.detail,n=Ye(t.name);if(!n){A();return}Q(n,t.name,!0)}function Qe(e){X=e;let t;try{t=Ne(e)}catch(e){console.error(`[UPI] badge injection failed:`,e);return}Z(),t.length>0&&d({type:`BADGES_SHOWN`,count:t.length},`USAGE`).catch(()=>{});for(let{badge:e,professor:n}of t)Q(e,n.name,!1,n.speculative??!1)}async function $e(){try{J=(await d({type:`GET_SETTINGS`},`SETTINGS`)).settings}catch(e){console.error(`[UPI] could not load settings, using defaults:`,e)}}async function $(){try{if(qe(),await $e(),!J.autoDetect){console.info(`[UPI] autoDetect is off; not scanning this page`);return}document.addEventListener(p,Xe),document.addEventListener(w,Ze);let e=Ce(document,Qe);window[q]=()=>{document.removeEventListener(p,Xe),document.removeEventListener(w,Ze),e()}}catch(e){console.error(`[UPI] failed to start:`,e)}}chrome.runtime?.onMessage?.addListener((e,t,n)=>{if(e?.type===`DIAGNOSE_PAGE`){try{n({type:`DIAGNOSTICS`,diagnostics:Ke(document)})}catch(e){n({type:`ERROR`,message:String(e)})}return!0}}),document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,()=>void $(),{once:!0}):$(),window.addEventListener(`unhandledrejection`,e=>{console.error(`[UPI] unhandled promise rejection:`,e.reason)});